function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(60, 400, 10);
  strokeWeight(2);
  circle(200,200,350);
  square(450,40,325);
}